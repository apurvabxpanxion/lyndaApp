import { Component } from '@angular/core';
import { ApiService } from '../api.service';
import {ActivatedRoute} from '@angular/router';

@Component({
  selector: 'messages',
  templateUrl: './messages.component.html',
  styleUrls: ['./messages.component.css']
})
export class MessagesComponent {
  title = 'app';

  constructor(private apiService:ApiService, private route: ActivatedRoute){}

  ngOnInit(){
    var userId = this.route.snapshot.params.id;
    this.apiService.getMessage(userId);
  }
}
