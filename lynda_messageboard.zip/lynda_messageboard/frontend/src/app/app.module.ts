import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule, HTTP_INTERCEPTORS } from "@angular/common/http";
import {MatButtonModule, MatCardModule, MatToolbarModule, MatListModule} from '@angular/material';
import { RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { ApiService } from './api.service';
import { AuthService } from './auth.service';
import { MessagesComponent } from './messages/messages.component';
import { RegisterComponent } from './register/register.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatInputModule} from '@angular/material/input';
import { FormsModule } from '@angular/forms';
import { LoginComponent } from './login/login.component';
import { UserComponent } from './user/user.component';
import { ProfileComponent } from './profile/profile.component';
import { PostComponent } from './post/post.component';
import { AuthInterceptorService } from './authInterceptors.service';

const routes = [
  {
    path:"", component:PostComponent
  },
  {
    path:"register", component:RegisterComponent
  },
  {
    path:"login", component:LoginComponent
  },
  {
    path:"users", component:UserComponent
  },
  {
    path:"profile/:id", component:UserComponent
  }
]
@NgModule({
  declarations: [
    AppComponent,
    MessagesComponent,
    RegisterComponent,
    LoginComponent,
    UserComponent,
    ProfileComponent,
    PostComponent
  ],
  imports: [
    BrowserModule,HttpClientModule, MatButtonModule, MatCardModule, MatToolbarModule, MatInputModule, BrowserAnimationsModule,
     RouterModule.forRoot(routes), FormsModule, MatListModule
  ],
  providers: [ApiService, AuthService, {
  provide: HTTP_INTERCEPTORS,
  useClass: AuthInterceptorService,
  multi: true
  }],
  bootstrap: [AppComponent]
})
export class AppModule { }
